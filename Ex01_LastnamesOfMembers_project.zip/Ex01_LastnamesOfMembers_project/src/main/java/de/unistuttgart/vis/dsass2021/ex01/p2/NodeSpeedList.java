package de.unistuttgart.vis.dsass2021.ex01.p2;

public class NodeSpeedList {

}
